#ifndef RESIZEABLE
#define RESIZEABLE

Class Resizeable{
	public:
	void enlarge(int n);
	void shrink(int n);
}

#endif