#ifndef CAR
#define CAR

Class Car final: public Vehicle 
{
	private:
	int seats;
	
	public:
	void turn();
}

#endif