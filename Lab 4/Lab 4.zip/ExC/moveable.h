#ifndef MOVEABLE
#define MOVEABLE

Class Moveable{
	public:
	void forward();
	void backward();
};

#endif